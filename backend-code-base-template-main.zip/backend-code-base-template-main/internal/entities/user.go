package entities

type User struct{}
