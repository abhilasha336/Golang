package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/golang-jwt/jwt/v4"
	"golang.org/x/oauth2"
	"golang.org/x/oauth2/google"
)

var oauthConfig = &oauth2.Config{
	RedirectURL:  os.Getenv("redirect_uri"),
	ClientID:     os.Getenv("client_id"),
	ClientSecret: os.Getenv("client_secret"),
	Scopes:       []string{"https://www.googleapis.com/auth/userinfo.email"},
	Endpoint:     google.Endpoint,
}

type MyData struct {
	ID            string `json:"id"`
	Email         string `json:"email"`
	VerifiedEmail bool   `json:"verified_email"`
	Picture       string `json:"picture"`
	Hd            string `json:"hd"`
}

var strCsrf = "abhilash"
var jwtKey = []byte("jwykey")

func main() {

	http.HandleFunc("/", handlerHome)
	http.HandleFunc("/login", handlerLogin)
	http.HandleFunc("/google/callback", handlerCallback)
	err := http.ListenAndServe(":3000", nil)
	if err != nil {
		fmt.Println("error running server")
		panic(err)

	}
	log.Print("server started on port:3000")
}

func handlerHome(w http.ResponseWriter, r *http.Request) {
	var html = `<html>
			<body>
				<a href="login">Google Sign in</a>
			</body>
		</html>`
	fmt.Fprint(w, html)
}

func handlerLogin(w http.ResponseWriter, r *http.Request) {
	url := oauthConfig.AuthCodeURL(strCsrf)
	fmt.Println("url is", url)
	http.Redirect(w, r, url, http.StatusTemporaryRedirect)
}

func handlerCallback(w http.ResponseWriter, r *http.Request) {
	if r.FormValue("state") != strCsrf {
		fmt.Println("state is not valid")
		http.Redirect(w, r, "/", http.StatusBadRequest)
	}
	token, err := oauthConfig.Exchange(context.Background(), r.FormValue("code"))
	if err != nil {
		fmt.Fprintln(w, err.Error())
		http.Redirect(w, r, "/", http.StatusBadRequest)

	}
	res, err := http.Get("https://www.googleapis.com/oauth2/v2/userinfo?access_token=" + token.AccessToken)
	if err != nil {
		fmt.Fprintln(w, err.Error())
		http.Redirect(w, r, "/", http.StatusBadRequest)
	}
	defer res.Body.Close()
	content, err := io.ReadAll(res.Body)
	if err != nil {
		fmt.Fprintln(w, err.Error())
		http.Redirect(w, r, "/", http.StatusBadRequest)
	}
	fmt.Fprint(w, string(content))

	payload := string(content)

	// Parse the JSON string
	var data MyData
	err = json.Unmarshal([]byte(payload), &data)
	if err != nil {
		fmt.Println("Error parsing JSON:", err)
		return
	}

	//2nd functionalities
	tokenString := GenerateJwtToken(data, 1)
	fmt.Fprint(w, tokenString)

}

// generated a new JWT token from the userid with given expiry time
func GenerateJwtToken(data MyData, expTime int) string {

	expirationTime := time.Now().Add(time.Duration(expTime) * time.Minute)
	newClaims := &Claims{
		UserId: data.ID,
		Email:  data.Email,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expirationTime),
		},
	}
	jwtToken := jwt.NewWithClaims(jwt.SigningMethodHS256, newClaims)
	token, err := jwtToken.SignedString(jwtKey)
	if err != nil {
		fmt.Println(err)
		return err.Error()
	}
	return token
}

type Claims struct {
	UserId               string // Change the data type of UserId to match your actual data type
	Email                string
	jwt.RegisteredClaims // Embedded to include the standard JWT claims
}
