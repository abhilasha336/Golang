drop table if exists users
