package repo

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"oauth/internal/entities"
)

type OauthRepo struct {
	repo *sql.DB
}

type OauthRepoImply interface {
	GetOauthCredentials(context.Context, string) (entities.OAuthData, error)
}

func NewOauthRepo(repo *sql.DB) OauthRepoImply {
	return &OauthRepo{
		repo: repo,
	}
}

func (oauth *OauthRepo) GetOauthCredentials(ctx context.Context, provider string) (entities.OAuthData, error) {

	var (
		credential entities.OAuthData
		scopes     entities.StringArray
	)

	GetCredentials := `SELECT
    provider_name,
    client_id,
    client_secret,
    redirect_url,
    scopes,
    state,
    token_url,
    jwt_key
FROM
oauth_table
WHERE
    provider_name = $1`
	row := oauth.repo.QueryRowContext(
		ctx,
		GetCredentials,
		provider)

	err := row.Scan(
		&credential.ProviderName,
		&credential.ClientID,
		&credential.ClientSecret,
		&credential.RedirectURL,
		&scopes,
		&credential.State,
		&credential.TokenURL,
		&credential.JWTKey,
	)

	if err != nil {
		log.Printf("scan:%v", err)
		return credential, err
	}
	credential.Scopes = scopes
	fmt.Printf("%+v", credential)
	return credential, nil
}
