package controllers

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"oauth/internal/entities"
	"oauth/internal/usecases"
	"oauth/utilities"
	"oauth/version"

	"github.com/gin-gonic/gin"
	"golang.org/x/oauth2"
)

type OauthController struct {
	router  *gin.RouterGroup
	useCase usecases.OuathUsecaseImply
}

func NewOauthController(router *gin.RouterGroup, useCase usecases.OuathUsecaseImply) *OauthController {
	return &OauthController{
		router:  router,
		useCase: useCase,
	}
}

// InitRoutes
func (oauth *OauthController) InitRoutes() {

	oauth.router.GET("/:version/health", func(ctx *gin.Context) {
		version.RenderHandler(ctx, oauth, "HealthHandler")
	})

	oauth.router.GET("/:version", func(ctx *gin.Context) {
		version.RenderHandler(ctx, oauth, "OauthHandler")
	})
	oauth.router.GET("/:version/callback", func(ctx *gin.Context) {
		version.RenderHandler(ctx, oauth, "OauthCallBackHandler")
	})

}

func (oauth *OauthController) OauthHandler(ctx *gin.Context) {

	provider := ctx.Query("provider")
	ctx.Set("provider", provider)
	oauthData, err := oauth.useCase.GetOauthCredentials(ctx, provider)
	if err != nil {
		log.Printf("controller: %v", err)
		ctx.JSON(http.StatusOK, gin.H{
			"status":  "failure",
			"message": err,
		})
		return
	}

	switch provider {
	case "google":
		entities.Endpoint = entities.Endpoints["google"]
	case "facebook":
		entities.Endpoint = entities.Endpoints["facebook"]
	case "spotify":
		entities.Endpoint = entities.Endpoints["spotify"]

	}

	fmt.Println("hilogin")
	config := utilities.Config(oauthData)
	url := config.AuthCodeURL(oauthData.State, oauth2.AccessTypeOffline)
	fmt.Println("urlll", url)
	http.SetCookie(ctx.Writer, &http.Cookie{
		Name:  "provider",
		Value: provider,
	})
	ctx.Redirect(http.StatusFound, url)

}

func (oauth *OauthController) OauthCallBackHandler(ctx *gin.Context) {

	fmt.Println("fate2")
	cookie, err := ctx.Request.Cookie("provider")
	if err != nil {
		ctx.JSON(http.StatusOK, gin.H{
			"status":  "failure",
			"message": "provider in cookie not available",
		})
		return
	}
	provider := cookie.Value
	fmt.Println("Provider:", provider)

	oauthData, err := oauth.useCase.GetOauthCredentials(ctx, provider)
	if err != nil {
		ctx.JSON(http.StatusOK, gin.H{
			"status":  "failure",
			"message": err,
		})
		return
	}
	config := utilities.Config(oauthData)

	log.Println("hitted google server")
	if ctx.Query("state") != oauthData.State {
		fmt.Println("state is not valid")
		ctx.Redirect(http.StatusBadRequest, "/")
		return
	}
	fmt.Println("stateeeeeeeee")
	token, err := config.Exchange(context.Background(), ctx.Query("code"))
	if err != nil {
		fmt.Fprintln(ctx.Writer, err.Error())
		ctx.Redirect(http.StatusBadRequest, "/")
		return
	}
	switch provider {
	case "spotify":
		client := config.Client(ctx, token)
		resp, err := client.Get("https://api.spotify.com/v1/me")
		if err != nil {
			ctx.String(http.StatusInternalServerError, fmt.Sprintf("Error fetching user details: %v", err))
			return
		}

		var user utilities.MyData
		if err := json.NewDecoder(resp.Body).Decode(&user); err != nil {
			ctx.String(http.StatusInternalServerError, fmt.Sprintf("Error decoding user details: %v", err))
			return
		}
		fmt.Printf("%+v", user)
		tokenString := utilities.GenerateJwtToken(user, 1)

		fmt.Fprint(ctx.Writer, tokenString)
		res := utilities.ValidateJwtToken(tokenString)
		fmt.Fprintf(ctx.Writer, "%+v", res)
	default:
		googleUserDetailsRequest, err := http.NewRequest("GET", oauthData.TokenURL+token.AccessToken, nil)
		if err != nil {
			fmt.Println("Error creating Google user details request:", err)
			return
		}

		resp, err := http.DefaultClient.Do(googleUserDetailsRequest)
		if err != nil {
			fmt.Fprintln(ctx.Writer, err.Error())
			ctx.Redirect(http.StatusBadRequest, "/")
			return
		}
		defer resp.Body.Close()
		content, err := io.ReadAll(resp.Body)
		if err != nil {
			fmt.Fprintln(ctx.Writer, err.Error())
			ctx.Redirect(http.StatusBadRequest, "/")
			return
		}
		fmt.Fprint(ctx.Writer, string(content))
		var data utilities.MyData
		err = json.Unmarshal(content, &data)
		if err != nil {
			fmt.Println("Error parsing JSON:", err)
			return
		}
		fmt.Printf("%+v", data)
		tokenString := utilities.GenerateJwtToken(data, 1)

		fmt.Fprint(ctx.Writer, tokenString)
		res := utilities.ValidateJwtToken(tokenString)
		fmt.Fprintf(ctx.Writer, "%+v", res)
	}

	// 2nd functionalities

}

// HealthHandler
func (oauth *OauthController) HealthHandler(ctx *gin.Context) {
	ctx.JSON(http.StatusOK, gin.H{
		"status":  "success",
		"message": "server run with base version",
	})
}
