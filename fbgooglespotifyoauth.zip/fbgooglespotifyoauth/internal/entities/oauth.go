package entities

import (
	"database/sql/driver"
	"encoding/json"
	"errors"

	"golang.org/x/oauth2"
	"golang.org/x/oauth2/facebook"
	"golang.org/x/oauth2/google"
	"golang.org/x/oauth2/spotify"
)

type StringArray []string

type OAuthData struct {
	ProviderName string      `json:"provider_name" db:"provider_name"`
	ClientID     string      `json:"client_id" db:"client_id"`
	ClientSecret string      `json:"client_secret" db:"client_secret"`
	RedirectURL  string      `json:"redirect_url" db:"redirect_url"`
	Scopes       StringArray `json:"scopes" db:"scopes"`
	State        string      `json:"state" db:"state"`
	TokenURL     string      `json:"token_url" db:"token_url"`
	JWTKey       string      `json:"jwt_key" db:"jwt_key"`
}

var Endpoint oauth2.Endpoint
var Endpoints = map[string]oauth2.Endpoint{
	"google":   google.Endpoint,
	"facebook": facebook.Endpoint,
	"spotify":  spotify.Endpoint,
	// Add more provider endpoints here
}

func (a *StringArray) Scan(value interface{}) error {
	b, ok := value.([]byte)
	if !ok {
		return errors.New("Scan source was not []byte")
	}

	return json.Unmarshal(b, a)
}

func (a *StringArray) Value() (driver.Value, error) {
	if a == nil {
		return nil, nil
	}
	return json.Marshal(a)
}
