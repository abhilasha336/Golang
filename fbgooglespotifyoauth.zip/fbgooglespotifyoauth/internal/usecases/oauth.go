package usecases

import (
	"context"
	"oauth/internal/entities"
	"oauth/internal/repo"
)

type OauthUseCase struct {
	useCase repo.OauthRepoImply
}

type OuathUsecaseImply interface {
	GetOauthCredentials(context.Context, string) (entities.OAuthData, error)
}

func NewOauthUseCase(oauth repo.OauthRepoImply) OuathUsecaseImply {
	return &OauthUseCase{
		useCase: oauth,
	}
}

func (oauth *OauthUseCase) GetOauthCredentials(ctx context.Context, provider string) (entities.OAuthData, error) {
	return oauth.useCase.GetOauthCredentials(ctx, provider)
}
